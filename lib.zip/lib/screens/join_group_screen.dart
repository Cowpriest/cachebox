import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class JoinGroupScreen extends StatefulWidget {
  @override
  _JoinGroupScreenState createState() => _JoinGroupScreenState();
}

class _JoinGroupScreenState extends State<JoinGroupScreen> {
  final _codeCtrl = TextEditingController();
  bool _loading = false;
  String? _error;

  Future<void> _join() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final uid = FirebaseAuth.instance.currentUser!.uid;
    final snap = await FirebaseFirestore.instance
        .collection('groups')
        .where('inviteCode', isEqualTo: _codeCtrl.text.trim())
        .get();
    if (snap.docs.isEmpty) {
      setState(() {
        _error = 'Invalid code';
        _loading = false;
      });
      return;
    }
    final grp = snap.docs.first;
    final members = List<String>.from(grp['members']);
    if (members.contains(uid)) {
      setState(() {
        _error = 'Already a member';
        _loading = false;
      });
      return;
    }
    members.add(uid);
    await grp.reference.update({'members': members});
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Join Group')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
                controller: _codeCtrl,
                decoration: InputDecoration(labelText: 'Invite Code')),
            if (_error != null) ...[
              SizedBox(height: 8),
              Text(_error!, style: TextStyle(color: Colors.red)),
            ],
            SizedBox(height: 20),
            _loading
                ? CircularProgressIndicator()
                : ElevatedButton(onPressed: _join, child: Text('Join')),
          ],
        ),
      ),
    );
  }
}
