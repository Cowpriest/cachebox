import 'package:flutter/material.dart';
import 'chat_screen.dart';
import 'files_screen.dart';

class GroupHomeScreen extends StatefulWidget {
  final String groupId;
  final String groupName;
  const GroupHomeScreen({required this.groupId, required this.groupName});

  @override
  _GroupHomeScreenState createState() => _GroupHomeScreenState();
}

class _GroupHomeScreenState extends State<GroupHomeScreen> {
  int _selected = 0;
  @override
  Widget build(BuildContext ctx) {
    final screens = [
      ChatScreen(groupId: widget.groupId),
      FilesScreen(),
    ];
    return Scaffold(
      appBar: AppBar(title: Text(widget.groupName)),
      body: screens[_selected],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selected,
        onTap: (i) => setState(() => _selected = i),
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.chat), label: 'Chat'),
          BottomNavigationBarItem(icon: Icon(Icons.folder), label: 'Files'),
        ],
      ),
    );
  }
}
