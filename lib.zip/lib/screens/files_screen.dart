// lib/screens/files_screen.dart

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;

import '../services/file_service.dart';
import '../services/file_model.dart';
import 'video_player_screen.dart';
import 'audio_player_screen.dart';
import 'image_viewer_screen.dart';
import 'text_viewer_screen.dart';

class FilesScreen extends StatefulWidget {
  final String groupId;
  final String ownerUid;
  final List<String> adminUids;

  const FilesScreen({
    required this.groupId,
    required this.ownerUid,
    required this.adminUids,
    Key? key,
  }) : super(key: key);

  @override
  State<FilesScreen> createState() => _FilesScreenState();
}

class _FilesScreenState extends State<FilesScreen> {
  List<FileModel> files = [];
  bool loading = false;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() => loading = true);
    try {
      final fetched = await FileService.listFiles(widget.groupId);
      setState(() => files = fetched);
    } catch (e, st) {
      // print to console for full stack
      debugPrint('❌ listFiles error: $e\n$st');
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('❌ Failed to fetch files:\n$e')));
    } finally {
      setState(() => loading = false);
    }
  }

  Future<void> _upload() async {
    try {
      await FileService.uploadFile(widget.groupId);
      await _refresh();
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('❌ Upload failed: $e')));
    }
  }

  Future<void> _openFile(FileModel file) async {
    final url = file.fileUrl;
    final ext = p.extension(file.fileName).toLowerCase();

    try {
      if (['.mp4', '.webm'].contains(ext)) {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => VideoPlayerScreen(videoUrl: url)),
        );
      } else if (['.mp3', '.wav'].contains(ext)) {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => AudioPlayerScreen(audioUrl: url)),
        );
      } else if (['.jpg', '.jpeg', '.png', '.gif'].contains(ext)) {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => ImageViewerScreen(imageUrl: url)),
        );
      } else {
        // treat everything else as text/code
        final response = await http.get(Uri.parse(url));
        Navigator.push(
          context,
          MaterialPageRoute(
            builder:
                (_) => TextViewerScreen(
                  textContent: utf8.decode(response.bodyBytes),
                  fileName: file.fileName,
                ),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('❌ Failed to load file')));
    }
  }

  Future<void> _delete(FileModel file) async {
    setState(() => loading = true);
    try {
      await FileService.deleteFile(widget.groupId, file);
      await _refresh();
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('❌ Delete failed: $e')));
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentUid = FirebaseAuth.instance.currentUser!.uid;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Group Files'),
        actions: [
          IconButton(onPressed: _upload, icon: const Icon(Icons.upload_file)),
        ],
      ),
      body:
          loading
              ? const Center(child: CircularProgressIndicator())
              : RefreshIndicator(
                onRefresh: _refresh,
                child: ListView.builder(
                  itemCount: files.length,
                  itemBuilder: (_, i) {
                    final file = files[i];
                    final currentUid = FirebaseAuth.instance.currentUser!.uid;
                    final canDelete =
                        currentUid == file.uploadedByUid ||
                        currentUid == widget.ownerUid ||
                        widget.adminUids.contains(currentUid);
                    return ListTile(
                      leading: const Icon(Icons.insert_drive_file),
                      title: Text(file.fileName),
                      subtitle: Text('by ${file.uploadedByName}'),
                      onTap: () => _openFile(file),
                      trailing:
                          canDelete
                              ? IconButton(
                                icon: const Icon(
                                  Icons.delete,
                                  color: Colors.red,
                                ),
                                onPressed: () => _delete(file),
                              )
                              : null,
                    );
                  },
                ),
              ),
    );
  }
}
