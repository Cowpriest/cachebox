// lib/globals.dart
import 'dart:async';

final Completer<void> justAudioBackgroundCompleter = Completer<void>();
